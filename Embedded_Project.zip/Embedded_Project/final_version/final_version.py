import cherrypy
from time import sleep
import threading
import socket

# set username and password for logging
dict_username_password = {
    "hamidreza": "123",
    "fatemeh": "2024",
} 
#############################################################################
#  connect NodeMCU and server for send dht11 of data
my_socket_dht = socket.socket()

port_dht = 8080

ip_dht = "192.168.43.248"

my_socket_dht.connect((ip_dht, port_dht))

#############################################################################
#  connect NodeMCU and server for send ds18b20 of data

my_socket_ds = socket.socket()

port_ds = 8080

ip_ds = "192.168.43.45"

my_socket_ds.connect((ip_ds, port_ds))



#############################################################################

class LoginApp:
    def __init__(self):
        # set default value for temperature of cows
        self.data1 = {
            "Alex1": 0,
            "Alex2": 23,
            "Alex3": 25,
        }
        ########################
        
        # set default value for temperature and humidity
        self.temprature = 0
        self.temp = 0
        self.hum = 0
        
        #########################
        
         # set default value for beat rate
        self.data2 = {
            "Alex1": 65,
            "Alex2": 84,
            "Alex3": 66,
        }
        
        #########################

        # set thread for def get_information and def login
        t1 = threading.Thread(target=self.get_information)
        t3 = threading.Thread(target=self.login)

        t1.start()
        t3.start()
        
        #########################
    # get information of NodeMCUs
    def get_information(self): 
        while True:
          
            ####################################################################################################
            
            information_dht = my_socket_dht.recv(1024).decode() # get information of dht11
            information_ds = my_socket_ds.recv(1024).decode() # get information of ds18b20
            
            ####################################################################################################

            lines = information_dht.split("\n") # seprate of temprature and humidity
            for line in lines:
                if "temp" in line:
                    temp = float(line.split(":")[-1])
                elif "hum" in line:
                    hum = float(line.split(":")[-1])
                    
            ####################################################################################################
            
            print(information_ds)
            self.hum = hum 
            self.temp = temp
            information_ds = information_ds.strip()
            
            ####################################################################################################
            
            # convert body of temperature to floating
            if information_ds:
                information_ds = float(information_ds)
                self.data1["Alex1"] = information_ds
                print(information_ds)

            ####################################################################################################
            print(
                "#############################################################################"
            )
            print("Temperature:", temp)
            print("Humidity:", hum)
            print(
                "#############################################################################"
            )
            
            ####################################################################################################

    # set loggin
    @cherrypy.expose
    def index(self, error_msg=None):
        return f"""
        <html>
        <head>
          <link rel="stylesheet" href="style.css">

        <meta charset="UTF-8">
	        <meta name="viewport" content="width=device-width, initial-scale=1">
            <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
            <style>
           @import url("https://fonts.googleapis.com/css2?family=Quicksand:wght@300&display=swap");
* {{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: "Quicksand", sans-serif;
}}
body {{
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  background: #111;
  width: 100%;
  overflow: hidden;
}}
.ring {{
  position: relative;
  width: 500px;
  height: 500px;
  display: flex;
  justify-content: center;
  align-items: center;
}}
.ring i {{
  position: absolute;
  inset: 0;
  border: 2px solid #fff;
  transition: 0.5s;
}}
.ring i:nth-child(1) {{
  border-radius: 38% 62% 63% 37% / 41% 44% 56% 59%;
  animation: animate 6s linear infinite;
}}
.ring i:nth-child(2) {{
  border-radius: 41% 44% 56% 59%/38% 62% 63% 37%;
  animation: animate 4s linear infinite;
}}
.ring i:nth-child(3) {{
  border-radius: 41% 44% 56% 59%/38% 62% 63% 37%;
  animation: animate2 10s linear infinite;
}}
.ring:hover i {{
  border: 6px solid var(--clr);
  filter: drop-shadow(0 0 20px var(--clr));
}}
@keyframes animate {{
  0% {{
    transform: rotate(0deg);
  }}
  100% {{
    transform: rotate(360deg);
  }}
}}
@keyframes animate2 {{
  0% {{
    transform: rotate(360deg);
  }}
  100% {{
    transform: rotate(0deg);
  }}
}}
.login {{
  position: absolute;
  width: 300px;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  gap: 20px;
}}
.login h2 {{
  font-size: 2em;
  color: #fff;
}}
.login .inputBx {{
  position: relative;
  width: 100%;
}}
.login .inputBx input {{
  position: relative;
  width: 100%;
  padding: 12px 20px;
  background: transparent;
  border: 2px solid #fff;
  border-radius: 40px;
  font-size: 1.2em;
  color: #fff;
  box-shadow: none;
  outline: none;
}}
.login .inputBx input[type="submit"] {{
  width: 100%;
  background: #0078ff;
  background: linear-gradient(45deg, #ff357a, #fff172);
  border: none;
  cursor: pointer;
}}
.login .inputBx input::placeholder {{
  color: rgba(255, 255, 255, 0.75);
}}
.login .links {{
  position: relative;
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 20px;
}}
.login .links a {{
  color: #fff;
  text-decoration: none;
}}
            </style>

        </head>
        <body>
            <form method="post" action="/login">

            
<link rel="stylesheet" href="2.css">
<!--ring div starts here-->
<div class="ring">
    <i style="--clr:#00ff0a;"></i>
    <i style="--clr:#ff0057;"></i>
    
    <i style="--clr:#fffd44;"></i>
    <div class="login">
      <h2>Login</h2>
      
      
                        <div class="inputBx">
                            <input type="text" name="username" placeholder="Username">
                        </div>
                        <div class="inputBx">
                            <input type="password" name="password"  color = "white"; id="passwordField" placeholder="Password">
                            <v class="fa fa-eye" id="togglePassword" onclick="togglePassword()" id="eyeField"; style="position: absolute; color:#835545; right: 14px; top: 50%;transform: scale(1.2);    height: 165%; cursor: pointer;" v=""></v>
                        </div>
                        <div class="inputBx">
                            <input type="submit" value="Sign in">
                        </div>
        
    <p  style="color:wheat; font-size: 18px;">{error_msg or ""}</p>
    </div>
  </div>
  
  </form>
  <script>
                function togglePassword() {{
                    var passwordField = document.getElementById('passwordField');
                    var togglePasswordButton = document.getElementById('togglePassword');
                    
                    if (passwordField.type === 'password') {{
                        passwordField.type = 'text';
                        togglePasswordButton.classList.remove('fa-eye');
                        togglePasswordButton.classList.add('fa-eye-slash');
                    }} else {{
                        passwordField.type = 'password';
                        togglePasswordButton.classList.remove('fa-eye-slash');
                        togglePasswordButton.classList.add('fa-eye');
                    }}
                }}
                                
            </script>
   
        </body>
        </html>
        """

    @cherrypy.expose
    def login(self, username=None, password=None):
        if username in dict_username_password: # check password and username
            if (dict_username_password[username]) == ((password)):
                temperature_cow = self.data1  
                temperature_cow1 = temperature_cow["Alex1"]
                temperature_cow2 = temperature_cow["Alex2"]
                temperature_cow3 = temperature_cow["Alex3"]

                beat_rate_cow = self.data2
                beat_rate_cow1 = beat_rate_cow["Alex1"]
                beat_rate_cow2 = beat_rate_cow["Alex2"]
                beat_rate_cow3 = beat_rate_cow["Alex3"]
                temp = self.temp
                hum = self.hum

                return f"""
        <html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <style>
  @import url("https://fonts.googleapis.com/css2?family=Quicksand:wght@300&display=swap");


body {{
                            
                        
                            

                        
                        background: linear-gradient(to bottom right, #b9f6f1, #96ebcb, aliceblue);


                        
                        
                        }}
.container {{

  display: flex;
  justify-content: center;
  align-items: center;
  height: 26vh;
}}

.sensor1 {{

  margin: 88px;
  padding: 45px;
  background-color: #fff;
  border-radius: 10px;
  border: 1.5px solid #a0a0a0;
  box-shadow: 10px 10px 10px #a0a0a0;
}}

.sensor2 {{

  margin: 88px;
  padding: 45px 55px;
  background-color: #fff;
  border-radius: 10px;
  border: 1.5px solid #a0a0a0;
  box-shadow: 10px 10px 10px #a0a0a0;
}}

.title {{
  font-size: 24px;
  font-weight: bold;
  color: #333;
  margin-bottom: 10px;
}}



.value{{
    font-size: 24px;
    text-align: center;

}}

 .table-container {{
                            
                            float: left; /* چینش کنار هم از طریق float */
                            margin-right: 20px; /* فاصله بین جداول */
                            margin-top: 45px;

                    }}
  
  
.table-light-theme th {{
                    
                        padding: 30px 125px;
                        text-align: center;
                        border: 1px solid black;
                        font-size: 25px;
                        font-weight: bold;
                        font-style: italic;
                        font-family: "Times New Roman", Times, serif;
                        background-color: rgba(0, 0, 0, 0.2);
                        color: white;
}}                  
.table-light-theme  td{{
    padding: 30px;
    text-align: center;
    border: 1px solid black;
    font-size: 25px;
    font-weight: bold;
    font-style: italic;
    font-family: "Times New Roman", Times, serif;

}}

.table-heading {{
                            text-align: center;
                            font-size: 24px;
                            font-weight: bold;
                            margin-bottom: 15px;
                        }}

                        .table-heading span {{
                            padding: 40px;
                        }}

@keyframes blink {{
  0% {{
    opacity: 1;
  }}
  50% {{
    opacity: 0;
  }}
  100% {{
    opacity: 1;
  }}
}}

.blink {{
  animation: blink 1s infinite;
}}
.warning {{ 
                color: red;
            }}  


</style>

</head>
<body>
  <div class="container">
<div class="sensor1">
            <h1 class="title">Temperature</h1>
            <div id="temperature" class="value { 'warning' if temp > 28  else '' }">
                <span id="temperatureValue" class="unit">{temp} ℃</span>
            </div>
        </div>
  
  
    <div class="sensor2">
      <h1 class="title">Humidity</h1>
      <div id="humidity" class="value">
        <span id="humidityValue" class="unit">{hum} %</span>
      </div>
    </div>
  </div>
  
  <div class="table-container" style="float: left; margin-left: 445px;">
            <table style="width: 700px; height: 540px;"> <!-- تغییر اندازه جدول به صورت inline -->
                            <tr class = "table-light-theme">
                                <th colspan="3" class="table-heading">Information</th>
                            </tr>
                            <tr class = "table-light-theme">
                                <th>Cow's Name</th>
                                <th>Temprature</th>
                                <th>heart beat</th>
                            </tr>
                            <tr class = "table-light-theme">
                                <td>&#8226; Alex1</td>
                                <!-- افزودن شناسه برای به‌روز رسانی داده -->
                                <td><span id="temperature_cow1" class="value { 'warning' if temperature_cow1 > 27  else '' }">{temperature_cow1}</span></td>
                                <td><span id="result4" class="value { 'warning' if beat_rate_cow1 > 70  else '' }">{beat_rate_cow1}</span></td>
                            </tr>
                            <tr class = "table-light-theme">
                                <td>&#8226; Alex2</td>
                                <!-- افزودن شناسه برای به‌روز رسانی داده -->
                                <td><span id="temperature_cow2" class="value { 'warning' if temperature_cow2 > 27  else '' }">{temperature_cow2}</span></td>
                                <td><span id="result5" class="value { 'warning' if beat_rate_cow2 > 70  else '' }">{beat_rate_cow2}</span></td>
                            </tr>
                            <tr class = "table-light-theme">
                                <td>&#8226; Alex3</td>
                                <!-- افزودن شناسه برای به‌روز رسانی داده -->
                                <td><span id="temperature_cow3" class="value { 'warning' if temperature_cow3 > 27  else '' }"> {temperature_cow3} </span></td>
                                <td><span id="result6" class="value { 'warning' if beat_rate_cow3 > 70  else '' }">{beat_rate_cow3}</span></td>
                            </tr>
                        </table>
                    </div>

  <script src="script.js"></script>
  <script>

document.addEventListener("DOMContentLoaded", function() {{
  // بررسی وجود مقادیر دما و ردیف‌های جدول
  var temperatureValue = document.getElementById("temperatureValue");
  var temperature_cow1 = document.getElementById("temperature_cow1");
  var temperature_cow2 = document.getElementById("temperature_cow2");
  var temperature_cow3 = document.getElementById("temperature_cow3");
  var result4 = document.getElementById("result4");
  var result5 = document.getElementById("result5");
  var result6 = document.getElementById("result6");

  // بررسی مقدار دما و اعمال انیمیشن در صورت لزوم
  
  if (temperature_cow1) {{
    var tempValue_body1 = parseFloat(temperature_cow1.innerText);
    if (tempValue_body1 > 27) {{
      // اعمال انیمیشن چشمک زن به ردیف مربوطه
      temperature_cow1.classList.add("blink");
    }}
  }}
  
  if (temperature_cow2) {{
    var tempValue_body2 = parseFloat(temperature_cow2.innerText);
    if (tempValue_body2 > 27) {{
      // اعمال انیمیشن چشمک زن به ردیف مربوطه
      temperature_cow2.classList.add("blink");
    }}
  }}
  
  if (temperature_cow3) {{
    var tempValue_body3 = parseFloat(temperature_cow3.innerText);
    if (tempValue_body3 > 27) {{
      // اعمال انیمیشن چشمک زن به ردیف مربوطه
      temperature_cow3.classList.add("blink");
    }}
  }}
  
  if (result4) {{
    var beat_rate1 = parseFloat(result4.innerText);
    if (beat_rate1 > 70) {{
      // اعمال انیمیشن چشمک زن به ردیف مربوطه
      result4.classList.add("blink");
    }}
  }}
  
  if (result5) {{
    var beat_rate2 = parseFloat(result5.innerText);
    if (beat_rate2 > 70) {{
      // اعمال انیمیشن چشمک زن به ردیف مربوطه
      result5.classList.add("blink");
    }}
  }}
  
  if (result6) {{
    var beat_rate3 = parseFloat(result6.innerText);
    if (beat_rate3 > 70) {{
      // اعمال انیمیشن چشمک زن به ردیف مربوطه
      result6.classList.add("blink");
    }}
  }}
    
}});
    window.onload = function() {{

      setTimeout(function() {{
        window.location.reload();
      }}, 2000);
    }}
  </script>
</body>
</html>

"""

            else:
                # Pass an error message to the index page
                return self.index(error_msg="Incorrect username or password.")

        else:
            # Pass an error message to the index page
            return self.index(error_msg="Incorrect username or password.")


if __name__ == "__main__":
    cherrypy.quickstart(LoginApp())
